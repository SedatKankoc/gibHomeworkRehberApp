package com.mulakat.rehber.service;


import java.util.List;

import com.mulakat.rehber.model.Rehber;

public interface RehberService {

	Rehber kisiKaydet(Rehber rehber);
	Rehber kisiGuncelle(Rehber rehber);
	void kisiSil(long id);
	List<Rehber> rehberiListele();
	Rehber idyeGoreKayitGetir(Long id) throws Exception;
	List<Rehber> ismeGoreKayitGetir(String isim) throws Exception;
	List<Rehber> pathGoreKayitGetir(String path, String value) throws Exception; 
	List<Rehber> isimveSoyismeGoreListele(String isim, String soyisim) throws Exception;
	

}
