package com.mulakat.rehber.controller;

import java.time.LocalDate;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mulakat.rehber.model.Rehber;
import com.mulakat.rehber.service.RehberService;

@RestController
@RequestMapping(value = "/rehber")
public class RehberController {

	Logger logger = LoggerFactory.getLogger(RehberController.class);

	private final RehberService rehberService;

	public RehberController(RehberService rehberService) {
		super();
		this.rehberService = rehberService;
	}

	@GetMapping
	public ArrayList<Rehber> rehberiListele() throws Exception {
		logger.info("Get all records request");
		ArrayList<Rehber> kayitliKisiler = (ArrayList<Rehber>) rehberService.rehberiListele();

		if (kayitliKisiler.size() == 0) {
			throw new Exception("Rehberde Kayıt Bulanamadı!");
		}
		return kayitliKisiler;
	}

	@GetMapping("/{id}")
	public Rehber rehberdenIdyeGoreKayıtGetir(@PathVariable(value = "id") long id) throws Exception {
		logger.info("Get record by id request id = " + id);
		Rehber kayitliKisi = rehberService.idyeGoreKayitGetir(id);
		logger.info("Return " + kayitliKisi.toString());
		return kayitliKisi;
	}
	
	@GetMapping("/ismeGore/{isim}")
	public ArrayList<Rehber> rehberdenIsmeGoreListele(@PathVariable(value = "isim") String isim) throws Exception{
		logger.info("Get record by name request isim = " + isim);
		ArrayList<Rehber> kayitliKisiler = (ArrayList<Rehber>) rehberService.ismeGoreKayitGetir(isim);
		logger.info("Return " + kayitliKisiler.toString());
		return kayitliKisiler;
	}
	
	@GetMapping("/isimveSoyismeGore/{isim}/{soyisim}")
	public ArrayList<Rehber> isimveSoyisimeGoreListele(@PathVariable String isim, @PathVariable String soyisim) throws Exception{
		logger.info("Get record by name and surname request isim = " + isim + " soyisim = " + soyisim);
		ArrayList<Rehber> kayitliKisiler = (ArrayList<Rehber>) rehberService.isimveSoyismeGoreListele(isim, soyisim);
		logger.info("Return " + kayitliKisiler.toString());
		return kayitliKisiler;
	}
	
	@GetMapping("/{path}/{value}")
	public ArrayList<Rehber> rehberdenPatheGoreListele(@PathVariable String path, @PathVariable String value) throws Exception{
		logger.info("Get record by path and value request isim = " + path + " soyisim = " + value);
		ArrayList<Rehber> kayitliKisiler = (ArrayList<Rehber>) rehberService.pathGoreKayitGetir(path, value);
		return kayitliKisiler;
	}

	@PostMapping
	public Rehber kisiKaydet(@RequestBody Rehber rehber) {
		Rehber result = new Rehber();
		logger.info("Save record request : " + rehber.toString());
		try {
			if (rehber.getIsim() == null) {
				throw new Exception("Kayıt eklenirken isim alanı boş bırakılamaz.");
			}
			if (rehber.getSoyisim() == null) {
				throw new Exception("Kayıt eklenirken soyisim alanı boş bırakılamaz");
			}
			if (rehber.getTelno() == null) {
				throw new Exception("Kayıt eklenirken telefon numarası alanı boş bıraklımaz");
			}
			rehber.setEklemeTarihi(LocalDate.now());
			rehber.setSilinmeTarihi(null);
			rehber.setDurum(1);
			result = rehberService.kisiKaydet(rehber);
			logger.info("Kaydedilen Kullanıcı:" + result.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rehberService.kisiKaydet(rehber);
	}

	@PutMapping
	public Rehber kisiGuncelle(@RequestBody Rehber inputRehber) throws Exception {
		logger.info("Update record request" + inputRehber.toString());
		if (inputRehber.getId() == null) {
			throw new Exception("Güncelleme işlemi için ID kolonu girilmelidir");
		}
		Rehber kayitliKisi = rehberService.idyeGoreKayitGetir(inputRehber.getId());
		if (inputRehber.getIsim() != null && !inputRehber.getIsim().isEmpty()
				&& (kayitliKisi.getIsim() == null || kayitliKisi.getIsim().isEmpty())
				|| (inputRehber.getIsim() != null && !inputRehber.getIsim().isEmpty() && kayitliKisi.getIsim() != null
						&& inputRehber.getIsim().compareTo(kayitliKisi.getIsim()) != 0)) {
			kayitliKisi.setIsim(inputRehber.getIsim());
		}
		if (inputRehber.getSoyisim() != null && !inputRehber.getSoyisim().isEmpty()
				&& (kayitliKisi.getSoyisim() == null || kayitliKisi.getSoyisim().isEmpty())
				|| (inputRehber.getSoyisim() != null && !inputRehber.getSoyisim().isEmpty()
						&& kayitliKisi.getSoyisim() != null
						&& inputRehber.getSoyisim().compareTo(kayitliKisi.getSoyisim()) != 0)) {
			kayitliKisi.setSoyisim(inputRehber.getSoyisim());
		}
		if (inputRehber.getEmail() != null && !inputRehber.getEmail().isEmpty()
				&& (kayitliKisi.getEmail() == null || kayitliKisi.getEmail().isEmpty())
				|| (inputRehber.getEmail() != null && !inputRehber.getEmail().isEmpty()
						&& kayitliKisi.getEmail() != null
						&& inputRehber.getEmail().compareTo(kayitliKisi.getEmail()) != 0)) {
			kayitliKisi.setEmail(inputRehber.getEmail());
		}
		if (inputRehber.getTelno() != null && !inputRehber.getTelno().isEmpty()
				&& (kayitliKisi.getTelno() == null || kayitliKisi.getTelno().isEmpty())
				|| (inputRehber.getTelno() != null && !inputRehber.getTelno().isEmpty()
						&& kayitliKisi.getTelno() != null
						&& inputRehber.getTelno().compareTo(kayitliKisi.getTelno()) != 0)) {
			kayitliKisi.setTelno(inputRehber.getTelno());
		}
		if (inputRehber.getEklemeTarihi() != null && kayitliKisi.getEklemeTarihi() == null || (inputRehber.getEklemeTarihi() != null
				&& kayitliKisi.getEklemeTarihi() != null && inputRehber.getEklemeTarihi().compareTo(kayitliKisi.getEklemeTarihi()) != 0)) {
			kayitliKisi.setEklemeTarihi(inputRehber.getEklemeTarihi());
		}
		if (inputRehber.getSilinmeTarihi() != null && kayitliKisi.getSilinmeTarihi() == null || (inputRehber.getSilinmeTarihi() != null
				&& kayitliKisi.getSilinmeTarihi() != null && inputRehber.getSilinmeTarihi().compareTo(kayitliKisi.getSilinmeTarihi()) != 0)) {
			kayitliKisi.setSilinmeTarihi(inputRehber.getSilinmeTarihi());
		}
		
		logger.info("Güncellenen Kullanıcı:" + kayitliKisi.toString());
		return rehberService.kisiGuncelle(kayitliKisi);
	}

	@DeleteMapping("/{id}")
	public void kisiyiTamamenSil(@PathVariable(value = "id") long id) throws Exception {
		logger.info("Silinilmesi istenen kişi ID:" + id);
		Rehber kayitliKisi = rehberService.idyeGoreKayitGetir(id);
		rehberService.kisiSil(id);
		logger.info("Silinen kişi bilgileri:" + kayitliKisi);
	}
	
	@DeleteMapping("/arsiv/{id}")
	public void kisiyiArsivle(@PathVariable(value = "id") long id) throws Exception {
		logger.info("Arşivlenmesi istenen kişi ID:" + id);
		Rehber kayitliKisi = rehberService.idyeGoreKayitGetir(id);
		kayitliKisi.setSilinmeTarihi(LocalDate.now());
		kayitliKisi.setDurum(0);
		rehberService.kisiGuncelle(kayitliKisi);
		logger.info("Arşivlenen kişi bilgileri:" + kayitliKisi);
	}

}
