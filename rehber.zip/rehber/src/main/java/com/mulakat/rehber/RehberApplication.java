package com.mulakat.rehber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RehberApplication {

	public static void main(String[] args) {
		SpringApplication.run(RehberApplication.class, args);
	}

}
