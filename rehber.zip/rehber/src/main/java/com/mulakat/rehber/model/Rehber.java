package com.mulakat.rehber.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rehber")
public class Rehber {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long id;
    @Column(name = "isim")
    private String isim;
    @Column(name = "soyisim")
    private String soyisim;
    @Column(name = "telno")
    private String telno;
    @Column(name = "ekleme_tarihi")
    private LocalDate eklemeTarihi;
    @Column(name = "silinme_tarihi", nullable = true)
    private LocalDate silinmeTarihi;
    @Column(name = "email", nullable = true)
    private String email;
    @Column(name = "durum")
    private int durum;

    public Rehber() {
		super();
	}
    
    

	public Rehber(String isim, String soyisim, String telno, String email) {
		super();
		this.isim = isim;
		this.soyisim = soyisim;
		this.telno = telno;
		this.email = email;
	}



	public Rehber(Long id, String isim, String soyisim, String telno, LocalDate eklemeTarihi, int durum) {
		super();
		this.id = id;
		this.isim = isim;
		this.soyisim = soyisim;
		this.telno = telno;
		this.eklemeTarihi = eklemeTarihi;
		this.durum = durum;
	}
	
	public Rehber(Long id, String isim, String soyisim, String telno, LocalDate eklemeTarihi, LocalDate silinmeTarihi,
			String email, int durum) {
		super();
		this.id = id;
		this.isim = isim;
		this.soyisim = soyisim;
		this.telno = telno;
		this.eklemeTarihi = eklemeTarihi;
		this.silinmeTarihi = silinmeTarihi;
		this.email = email;
		this.durum = durum;
	}


	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIsim() {
		return isim;
	}
	public void setIsim(String isim) {
		this.isim = isim;
	}
	public String getSoyisim() {
		return soyisim;
	}
	public void setSoyisim(String soyisim) {
		this.soyisim = soyisim;
	}
	public String getTelno() {
		return telno;
	}
	public void setTelno(String telno) {
		this.telno = telno;
	}
	public LocalDate getEklemeTarihi() {
		return eklemeTarihi;
	}
	public void setEklemeTarihi(LocalDate eklemeTarihi) {
		this.eklemeTarihi = eklemeTarihi;
	}
	public LocalDate getSilinmeTarihi() {
		return silinmeTarihi;
	}
	public void setSilinmeTarihi(LocalDate silinmeTarihi) {
		this.silinmeTarihi = silinmeTarihi;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getDurum() {
		return durum;
	}
	public void setDurum(int durum) {
		this.durum = durum;
	}

	
	@Override
	public String toString() {
		return "Rehber [id=" + id + ", isim=" + isim + ", soyisim=" + soyisim + ", telno=" + telno + ", eklemeTarihi="
				+ eklemeTarihi + ", silinmeTarihi=" + silinmeTarihi + ", email=" + email + ", durum=" + durum + "]";
	}
}
