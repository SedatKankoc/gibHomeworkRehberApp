package com.mulakat.rehber.serviceImpl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

import com.mulakat.rehber.model.Rehber;
import com.mulakat.rehber.repository.RehberRepository;
import com.mulakat.rehber.service.RehberService;

@SuppressWarnings("unchecked")
@Service
public class RehberServiceImpl implements RehberService {

	@PersistenceContext
	private EntityManager entityManager;

	public final RehberRepository rehberRepository;

	public RehberServiceImpl(RehberRepository rehberRepository, EntityManager entityManager) {
		super();
		this.rehberRepository = rehberRepository;
		this.entityManager = entityManager;
	}

	@Override
	public Rehber kisiKaydet(Rehber rehber) {
		Rehber kisiKayıt = rehberRepository.save(rehber);
		return kisiKayıt;
	}

	@Override
	public Rehber kisiGuncelle(Rehber rehber) {
		Rehber kisiGuncelle = rehberRepository.save(rehber);
		return kisiGuncelle;
	}

	@Override
	public void kisiSil(long id) {
		rehberRepository.deleteById(id);
	}

	@Override
	public List<Rehber> rehberiListele() {
		return rehberRepository.findAll();
	}

	@Override
	public Rehber idyeGoreKayitGetir(Long id) throws Exception {
		Optional<Rehber> optionalRehber = rehberRepository.findById(id);
		if (optionalRehber.isEmpty() || optionalRehber.get() == null) {
			throw new Exception(id + " id Numaralı Kişi Rehberde Bulunamadı");
		}
		return optionalRehber.get();
	}

	@Override
	public List<Rehber> ismeGoreKayitGetir(String isim) throws Exception {
		String query = "SELECT r FROM Rehber r WHERE r.isim LIKE '%" + isim + "%'";
		List<Rehber> result = (List<Rehber>) entityManager.createQuery(query,Rehber.class).getResultList();
		if(result == null || result.size() == 0) {
        	throw new Exception("Gelen İsme (" + isim + ") ait bir Kişi Rehberde Bulunamadı.");
        }
		return result;
	}
	
	@Override
	public List<Rehber> isimveSoyismeGoreListele(String isim, String soyisim) throws Exception {
		String query = "SELECT r FROM Rehber r WHERE r.isim LIKE '" + isim + "%' and r.soyisim LIKE '" + soyisim + "%'";
		List<Rehber> result = (List<Rehber>) entityManager.createQuery(query,Rehber.class).getResultList();
		if(result == null || result.size() == 0) {
        	throw new Exception("Gelen Bilgilerle  ait bir Kişi Rehberde Bulunamadı. Bilgiler : ["+isim+"],["+soyisim+"]");
        }
		return result;
	}
	
	@Override
	public List<Rehber> pathGoreKayitGetir(String path, String value) throws Exception {
		String query = "SELECT r FROM Rehber r WHERE r." + path + " LIKE '%" + value + "%'";
		List<Rehber> result = (List<Rehber>) entityManager.createQuery(query,Rehber.class).getResultList();
		if(result == null || result.size() == 0) {
        	throw new Exception("Gelen Bilgilerle  ait bir Kişi Rehberde Bulunamadı. Bilgiler : ["+path+"],["+value+"]");
        }
		return result;
	}

}
