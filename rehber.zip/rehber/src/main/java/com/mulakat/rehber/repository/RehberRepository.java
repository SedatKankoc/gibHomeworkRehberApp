package com.mulakat.rehber.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mulakat.rehber.model.Rehber;

@Repository
public interface RehberRepository extends JpaRepository<Rehber, Long>{
	
	
	
	

}
